<?php

require_once "./view/header.php";
require_once "./controller/ControllerLocatif.php";

$control = new ControllerLocatif();

if (isset($_GET["action"])) {

    switch ($_GET["action"]) {

        case 'add':
            // $control->add();
            break;
        case 'edit':
            // $control->edit();
            break;
        case 'remove':
            // $control->remove();
            break;
        case 'list':
            $control->list();
            break;
        case 'recherche':
            // $control->research();
            break;

        default:
            # TODO page non conforme aux spécifications
            echo "Page Invalide " . $_GET["action"] . "<br>";
            break;
    }
} else {
    // TODO page défaut ?
    echo "Page non définie<br>";
}


require_once "./view/footer.php";
