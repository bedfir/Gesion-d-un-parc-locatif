GRANT USAGE ON *.* TO 'app_loc'@'%';

GRANT ALL PRIVILEGES ON `app\_loc`.* TO 'app_loc'@'%';

GRANT ALL PRIVILEGES ON `app_loc`.* TO 'app_loc'@'%';